#!/usr/bin/python2
import os
import time
from colorama import Fore,Back,Style  
start = input(Fore.YELLOW + Style.BRIGHT +" [*] WELCOME PRESS 1 TO START ATTACK [*] ")
if "1":
    print(Fore.MAGENTA + Style.BRIGHT + " [*] STARTING TOOL PLEASE WAIT ........... [*] ")
    time.sleep(0.5)
    os.system('python EXPLOIT/2.py')